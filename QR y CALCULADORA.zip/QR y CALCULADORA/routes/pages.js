const express = require("express");
const path = require("path");
const router = express.Router();

router.get('/presentacion.html', (req, res) =>{
    res.sendFile(path.join(__dirname,'../public','/presentacion.html'))
});

router.get('/index2.html', (req, res) =>{
    res.sendFile(path.join(__dirname,'../public','/index2.html'))
});

router.get('/index.html', (req, res) =>{
    res.sendFile(path.join(__dirname,'../public','/index.html'))
});

router.get('/presentacion.css', (req, res) =>{
    res.sendFile(path.join(__dirname,'../public','/presentacion.css'))
});

router.get('/estilos.css', (req, res) =>{
    res.sendFile(path.join(__dirname,'../public','/estilos.css'))
});

router.get('/estiloqrs.css', (req, res) =>{
    res.sendFile(path.join(__dirname,'../public','/estilosqr.css'))
});
router.get('/app2.js', (req, res) =>{
    res.sendFile(path.join(__dirname,'../public','/app2.js'))
});
router.get('/pages.js', (req, res) =>{
    res.sendFile(path.join(__dirname,'../public','/pages.js'))
});

module.exports=router;